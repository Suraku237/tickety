// =============================================================
// AUTH USER MODEL
// lib/models/auth_user.dart
// =============================================================

/// Represents the currently authenticated user.
///
/// All fields are immutable. To update, create a new instance
/// via [copyWith].
class AuthUser {
  /// Display name (may include spaces, e.g. "Jane Doe").
  final String username;

  /// Primary email address.
  final String email;

  /// Optional phone number (E.164 format preferred).
  final String? phone;

  /// Optional remote URL or local asset path for the avatar.
  final String? avatarUrl;

  /// Unique backend identifier for this user.
  final String id;

  /// Whether the account has been verified (email confirmed, etc.).
  final bool isVerified;

  const AuthUser({
    required this.id,
    required this.username,
    required this.email,
    this.phone,
    this.avatarUrl,
    this.isVerified = true,
  });

  // ── Derived helpers ────────────────────────────────────────

  /// Returns up to two uppercase initials derived from [username].
  ///
  /// Examples:
  /// - "Jane Doe"  → "JD"
  /// - "Alice"     → "A"
  /// - ""          → "?"
  String get initials {
    final trimmed = username.trim();
    if (trimmed.isEmpty) return '?';
    final parts = trimmed.split(RegExp(r'\s+'));
    if (parts.length >= 2) {
      return '${parts[0][0]}${parts[1][0]}'.toUpperCase();
    }
    return trimmed[0].toUpperCase();
  }

  /// Returns the first word of [username] (first name).
  String get firstName {
    final trimmed = username.trim();
    if (trimmed.isEmpty) return 'User';
    return trimmed.split(RegExp(r'\s+')).first;
  }

  // ── Immutable update ───────────────────────────────────────

  AuthUser copyWith({
    String? id,
    String? username,
    String? email,
    String? phone,
    String? avatarUrl,
    bool? isVerified,
  }) {
    return AuthUser(
      id:          id          ?? this.id,
      username:    username    ?? this.username,
      email:       email       ?? this.email,
      phone:       phone       ?? this.phone,
      avatarUrl:   avatarUrl   ?? this.avatarUrl,
      isVerified:  isVerified  ?? this.isVerified,
    );
  }

  // ── Serialisation ──────────────────────────────────────────

  factory AuthUser.fromJson(Map<String, dynamic> json) => AuthUser(
        id:         json['id']          as String,
        username:   json['username']    as String,
        email:      json['email']       as String,
        phone:      json['phone']       as String?,
        avatarUrl:  json['avatar_url']  as String?,
        isVerified: (json['is_verified'] as bool?) ?? true,
      );

  Map<String, dynamic> toJson() => {
        'id':          id,
        'username':    username,
        'email':       email,
        'phone':       phone,
        'avatar_url':  avatarUrl,
        'is_verified': isVerified,
      };

  // ── Object overrides ───────────────────────────────────────

  @override
  bool operator ==(Object other) =>
      identical(this, other) ||
      other is AuthUser && runtimeType == other.runtimeType && id == other.id;

  @override
  int get hashCode => id.hashCode;

  @override
  String toString() =>
      'AuthUser(id: $id, username: $username, email: $email, '
      'phone: $phone, isVerified: $isVerified)';
}